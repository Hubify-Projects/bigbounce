#!/bin/bash
# Launch parallel MCMC chains using learned covariance matrices
# Each chain runs independently with good proposals from the first chain

BASEDIR=/workspace/bigbounce/reproducibility
CHAINS_DIR=$BASEDIR/chains
N_EXTRA=6  # extra chains per dataset (plus 1 existing = 7 total per dataset)

export OMP_NUM_THREADS=4
export MKL_NUM_THREADS=4

datasets=(
  "planck_only:cosmology/cobaya_planck.yaml"
  "planck_bao:cosmology/cobaya_planck_bao.yaml"
  "planck_bao_sn:cosmology/cobaya_planck_bao_sn.yaml"
  "full_tension:cosmology/cobaya_full_tension.yaml"
)

cd $BASEDIR

for ds_config in "${datasets[@]}"; do
  IFS=: read -r ds yaml <<< "$ds_config"
  covmat="$CHAINS_DIR/${ds}/spin_torsion.covmat"
  
  if [ ! -f "$covmat" ]; then
    echo "WARNING: No covmat for $ds, skipping"
    continue
  fi
  
  echo "=== Starting $N_EXTRA parallel chains for $ds ==="
  
  for i in $(seq 2 $((N_EXTRA+1))); do
    outdir="$CHAINS_DIR/${ds}_chain${i}"
    mkdir -p "$outdir"
    
    # Create modified yaml pointing to new output dir and using learned covmat
    cat > "/tmp/cobaya_${ds}_chain${i}.yaml" << YAMLEOF
# Auto-generated parallel chain config for $ds (chain $i)
include: $BASEDIR/$yaml

output: $outdir/spin_torsion

sampler:
  mcmc:
    covmat: $covmat
    burn_in: 0.1
    learn_proposal: true
    learn_proposal_Rminus1_max: 50
YAMLEOF
    
    nohup cobaya-run "/tmp/cobaya_${ds}_chain${i}.yaml" \
      > "/workspace/outputs/cobaya_${ds}_chain${i}.log" 2>&1 &
    
    echo "  Started chain $i for $ds (PID: $!, log: cobaya_${ds}_chain${i}.log)"
    sleep 1  # stagger starts slightly
  done
done

echo ""
echo "=== All parallel chains launched ==="
echo "Total new processes: $((N_EXTRA * 4))"
echo "Total chains per dataset: $((N_EXTRA + 1))"
echo "Expected CPU usage: $((N_EXTRA * 4 * OMP_NUM_THREADS)) threads + existing"
