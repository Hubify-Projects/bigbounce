#!/bin/bash
# BigBounce MCMC Convergence Monitor
# Runs every 30 minutes, checks all chains per dataset

CHAINS_DIR="/workspace/bigbounce/reproducibility/chains"
OUTPUT_DIR="/workspace/outputs"
LOG="$OUTPUT_DIR/convergence_log.txt"
FLAG="$OUTPUT_DIR/CONVERGENCE_REACHED"

mkdir -p "$OUTPUT_DIR"

echo "========================================" >> "$LOG"
echo "Convergence check: $(date)" >> "$LOG"
echo "========================================" >> "$LOG"

DATASETS=("planck_only" "planck_bao" "planck_bao_sn" "full_tension")
ALL_CONVERGED=true
TOTAL_EFFECTIVE=0

for dataset in "${DATASETS[@]}"; do
    echo "" >> "$LOG"
    echo "--- $dataset ---" >> "$LOG"
    
    # Find all chain files for this dataset (original + parallel)
    CHAIN_FILES=""
    
    # Original chain
    ORIG="$CHAINS_DIR/$dataset/spin_torsion.1.txt"
    if [ -f "$ORIG" ]; then
        LINES=$(wc -l < "$ORIG" 2>/dev/null || echo "0")
        CHAIN_FILES="$ORIG ($LINES lines)"
        echo "  Original: $LINES lines" >> "$LOG"
    fi
    
    # Parallel chains
    PARALLEL_COUNT=0
    PARALLEL_TOTAL=0
    for chain_dir in "$CHAINS_DIR/${dataset}_chain"*/; do
        if [ -d "$chain_dir" ]; then
            CFILE="$chain_dir/spin_torsion.1.txt"
            if [ -f "$CFILE" ]; then
                LINES=$(wc -l < "$CFILE" 2>/dev/null || echo "0")
                PARALLEL_COUNT=$((PARALLEL_COUNT + 1))
                PARALLEL_TOTAL=$((PARALLEL_TOTAL + LINES))
            fi
        fi
    done
    echo "  Parallel chains: $PARALLEL_COUNT producing ($PARALLEL_TOTAL total lines)" >> "$LOG"
    
    # Use python + getdist to compute effective samples
    python3 -c "
import sys
import glob
import numpy as np

dataset = '$dataset'
chains_dir = '$CHAINS_DIR'

# Collect all chain files
files = []
orig = f'{chains_dir}/{dataset}/spin_torsion.1.txt'
import os
if os.path.exists(orig):
    files.append(orig)

for d in sorted(glob.glob(f'{chains_dir}/{dataset}_chain*/')):
    f = os.path.join(d, 'spin_torsion.1.txt')
    if os.path.exists(f):
        files.append(f)

if not files:
    print(f'  No chain files found')
    sys.exit(0)

# Read and combine chains
all_data = []
for f in files:
    try:
        data = np.loadtxt(f)
        if len(data.shape) == 2 and data.shape[0] > 2:
            all_data.append(data)
    except:
        pass

if not all_data:
    print(f'  No valid data yet')
    sys.exit(0)

combined = np.vstack(all_data)
weights = combined[:, 0]
raw_samples = len(combined)

# Effective sample count (sum of weights)
n_eff = int(np.sum(weights))

# Parameter estimates (columns: weight, -loglike, params...)
if combined.shape[1] >= 6:
    # Typical param order: H0, sigma8, nnu, omegam, ...
    # Just report basic stats
    param_cols = combined[:, 2:]  # skip weight and -loglike
    w = weights / np.sum(weights)
    means = np.average(param_cols, weights=w, axis=0)
    stds = np.sqrt(np.average((param_cols - means)**2, weights=w, axis=0))
    
    print(f'  Raw samples: {raw_samples} | Effective: {n_eff}')
    print(f'  Chains combined: {len(all_data)}')
    if param_cols.shape[1] >= 4:
        labels = ['H0', 'omegabh2', 'omegach2', 'nnu']
        for i, lbl in enumerate(labels[:min(4, param_cols.shape[1])]):
            print(f'    {lbl}: {means[i]:.4f} +/- {stds[i]:.4f}')
else:
    print(f'  Raw samples: {raw_samples} | Effective: {n_eff}')
    print(f'  (too few columns for parameter extraction)')

# Report convergence status
if n_eff >= 300:
    print(f'  STATUS: CONVERGED (>= 300 effective)')
else:
    print(f'  STATUS: RUNNING ({n_eff}/300 effective)')
    
print(f'EFFECTIVE_{dataset}={n_eff}')
" 2>&1 | tee -a "$LOG"
    
    # Extract effective count for convergence check
    EFF=$(grep "EFFECTIVE_${dataset}=" "$LOG" | tail -1 | cut -d= -f2)
    if [ -z "$EFF" ] || [ "$EFF" -lt 300 ] 2>/dev/null; then
        ALL_CONVERGED=false
    else
        TOTAL_EFFECTIVE=$((TOTAL_EFFECTIVE + EFF))
    fi
done

echo "" >> "$LOG"
echo "Total effective across converged datasets: $TOTAL_EFFECTIVE" >> "$LOG"

if [ "$ALL_CONVERGED" = true ]; then
    echo "" >> "$LOG"
    echo "*** ALL DATASETS CONVERGED! ***" >> "$LOG"
    echo "Creating flag file: $FLAG" >> "$LOG"
    touch "$FLAG"
    echo "CONVERGENCE_REACHED" >> "$LOG"
else
    echo "Not all datasets converged yet. Checking again in 30 min." >> "$LOG"
fi

echo "" >> "$LOG"
echo "Next check in 30 minutes..." >> "$LOG"
echo "" >> "$LOG"
